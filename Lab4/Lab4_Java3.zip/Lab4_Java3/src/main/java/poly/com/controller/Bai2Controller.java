package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet({"/calculate", "/calculate/add", "/calculate/sub"})
public class Bai2Controller extends HttpServlet {
	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        req.getRequestDispatcher("/calculate/pheptinh.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // TODO Auto-generated method stub
        
        String a = req.getParameter("a");
        String b = req.getParameter("b");
        String path = req.getServletPath();

        // Xử lý phép cộng nếu URL kết thúc bằng "/add"
        if (path.endsWith("/add")) {
            Double c = Double.valueOf(a) + Double.valueOf(b);
            req.setAttribute("message", a + " + " + b + " = " + c);
        } 
        // Xử lý phép trừ nếu không phải "/add" (hoặc nếu URL kết thúc bằng "/sub")
        else { 
            Double c = Double.valueOf(a) - Double.valueOf(b);
            req.setAttribute("message", a + " - " + b + " = " + c);
        }

        // Chuyển hướng về trang hiển thị kết quả
        req.getRequestDispatcher("/calculate/pheptinh.jsp").forward(req, resp);
    }
}

