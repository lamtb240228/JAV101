package poly.com.controller;

import java.io.File;
import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig
@WebServlet("/add")
public class Bai3Controller extends HttpServlet {
private static final long serrialVersionUID = 1L;

private static final String UPLOAD_DIRECTORY = "uploads";
@Override
protected void doGet(HttpServletRequest req,HttpServletResponse resp )  throws ServletException, IOException {
	//TODO Auto-generated method stub
	req.getRequestDispatcher("/from.jsp").forward(req, resp);
}

@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
	String fullname = req.getParameter("fullname");
	String password = req.getParameter("password");
	String gender = req.getParameter("gender");
	String married = req.getParameter("married");
	String country = req.getParameter("country");
	String[] hobbies = req.getParameterValues("hobbies");
	String note = req.getParameter("note");
	
	Part filePart = req.getPart("photo_file");
	String fileName =filePart.getSubmittedFileName();
	
	//String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY;
	String uploadPath = "C:/Anh";
	File uploadDir = new File(uploadPath);
	if (!uploadDir.exists()) {
		uploadDir.mkdir();
	}
	String filePath = uploadPath + File.separator + fileName;
	filePart.write(filePath);
	
	String photoURL = UPLOAD_DIRECTORY + "/" + fileName;
	
	req.setAttribute("fullname", fullname);
	req.setAttribute("password", password);
	req.setAttribute("gender", gender);
	req.setAttribute("married", married != null ? "Yes" : "No");
	req.setAttribute("country", country);
	req.setAttribute("hobbies", hobbies);
	req.setAttribute("note", note);
	req.setAttribute("photoURL", photoURL); // Truyền đường dẫn ảnh

	System.out.println("Ảnh được lưu tại: " + filePath);

	
	req.getRequestDispatcher("/ketqua.jsp").forward(req, resp);
	}
}
