package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/bai3")
public class Bai3controller extends HttpServlet{
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	// TODO Auto-generated method stub
	String url = req.getRequestURL().toString();
    String uri = req.getRequestURI();
    String queryString = req.getQueryString();
    String servletPath = req.getServletPath();
    String contextPath = req.getContextPath();
    String pathInfo = req.getPathInfo();
    String method = req.getMethod();

    // --- Output to browser ---
    resp.getWriter().println("<html><body>");
    resp.getWriter().println("<h2>Thông tin URL</h2>");
    resp.getWriter().println("<b>1. URL:</b> " + url + "<br>");
    resp.getWriter().println("<b>2. URI:</b> " + uri + "<br>");
    resp.getWriter().println("<b>3. QueryString:</b> " + queryString + "<br>");
    resp.getWriter().println("<b>4. ServletPath:</b> " + servletPath + "<br>");
    resp.getWriter().println("<b>5. ContextPath:</b> " + contextPath + "<br>");
    resp.getWriter().println("<b>6. PathInfo:</b> " + pathInfo + "<br>");
    resp.getWriter().println("<b>7. Method:</b> " + method + "<br>");
    resp.getWriter().println("</body></html>");
}
}
