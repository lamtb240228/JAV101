package poly.com.model;

public class Departments {

}
