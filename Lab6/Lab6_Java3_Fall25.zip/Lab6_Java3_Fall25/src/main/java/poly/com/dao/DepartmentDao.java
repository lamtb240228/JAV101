package poly.com.dao;

import java.sql.ResultSet;
import java.sql.Statement;

public class DepartmentDao extends ConnectDB{
	public void printAllDepartments() {
        String sql = "SELECT * FROM Departments";
        try 
        {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (!rs.isBeforeFirst()) {
                System.out.println("Không có phòng ban nào!");
                return;
            }
            while (rs.next()) {
                String id = rs.getString("id");
                String name = rs.getString("Name");
                String description = rs.getString("Description");
                System.out.println("ID: " + id + ", Name: " + name + ", Description: " + description);
            }
        } 
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
